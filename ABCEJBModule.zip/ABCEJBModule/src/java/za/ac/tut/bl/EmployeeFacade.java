/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import za.ac.tut.entities.Employee;

/**
 *
 * @author Student
 */
@Stateless
public class EmployeeFacade extends AbstractFacade<Employee> implements EmployeeFacadeLocal {

    @PersistenceContext(unitName = "ABCEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EmployeeFacade() {
        super(Employee.class);
    }

    @Override
    public List<Employee> findHighTempEmployees() {

        Query query = em.createQuery("SELECT DISTINCT e FROM Employee e JOIN e.temperature t WHERE t > 38");
        List<Employee> high = (List<Employee>) query.getResultList();

        return high;
    }

    @Override
    public List<Employee> findAcceptableTempEmployees() {

        Query query = em.createQuery("SELECT DISTINCT e FROM Employee e JOIN e.temperature t WHERE t <= 38");
        List<Employee> low = (List<Employee>) query.getResultList();

        return low;
    }

    @Override
    public List<Employee> FrequentlyHighTempEmployees() {

        Query query = em.createQuery("SELECT e FROM Employee e JOIN e.temperature t WHERE t > 38 GROUP BY e HAVING COUNT(t) > 2");
        List<Employee> frequent = (List<Employee>) query.getResultList();

        return frequent;
    }

}
