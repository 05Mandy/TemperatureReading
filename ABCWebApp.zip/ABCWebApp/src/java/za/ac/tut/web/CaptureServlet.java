/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.bl.EmployeeFacadeLocal;
import za.ac.tut.entities.Employee;

/**
 *
 * @author Student
 */
public class CaptureServlet extends HttpServlet {

    @EJB
    EmployeeFacadeLocal efl;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Long id = Long.parseLong(request.getParameter("id"));
        String name = request.getParameter("name");

        List<Double> myTemp = new ArrayList<>();
        String[] tempArray = request.getParameterValues("temp");
        String outcome = "Acceptable";

        if (tempArray != null) {
            for (String temp : tempArray) {
                Double temperature = Double.parseDouble(temp);
                myTemp.add(temperature);
                
                if (temperature > 38) {
                    outcome = "High";
                }
            }
        }

        Date time = new Date();

        Employee employee = new Employee(id, name, myTemp, outcome, time);
        efl.create(employee);

        RequestDispatcher disp = request.getRequestDispatcher("capture_outcome.jsp");
        disp.forward(request, response);
    }
}
